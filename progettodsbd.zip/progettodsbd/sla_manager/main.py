from datetime import timedelta
import time
import json
from flask import Flask , request , render_template
import requests
from prometheus_api_client.utils import parse_datetime
from prometheus_api_client import PrometheusConnect , MetricRangeDataFrame
from statsmodels.tsa.holtwinters import ExponentialSmoothing


try:
    prom = PrometheusConnect(url="http://15.160.61.227:29090",disable_ssl=True)
except prometheus_api_client.exceptions.PrometheusApiClientException as e:
    sys.exit("ERRORE CONNESSIONE AL PROMETHEUS")


metric_name = []
json_check={}
file_jsonSla={}
app = Flask(__name__)



def check_violation(fileJsonSLA):

    global metric_name
    nodeName = ['sv122','invader-26','i70','sv192','sv121']
    job = ['summary','haproxy','summary','system','summary']
    start_time= ["10m","15m","20m"] # 1,3,12h
    end_time = parse_datetime("now")
    chunk_size = timedelta(minutes=1)
    
    # Scraping metriche da prometheus

    for i in range(5):
        for x in start_time:
            label_config={'nodeName': nodeName[i], 'job': job[i]}
            
            metric_data,diff_meta = configureParams(metric_name[i],label_config,parse_datetime(x),end_time,chunk_size)

            
            metric_df=MetricRangeDataFrame(metric_data)
            create_values(metric_name[i],metric_df,x)

    print(json_check)
    past_violation_json = {}

    # Verifico se ci sono state o meno violazioni
    for key in json_check.keys():
        num_violation=0
        z=key.split('-')
        
        #
        for k in json_check[key].get('values'):
            #print(fileJsonSLA[z[0]].get('min'))
            #print(k)
            if not (float(fileJsonSLA[z[0]].get('min')) < k < float(fileJsonSLA[z[0]].get('max'))):
                num_violation = num_violation +1
        
        past_violation_json[key]={"num_violation": num_violation}
    

    return past_violation_json


def prediction_violation(fileJsonSLA):
    prediction_json={}
    json1={}
    v=[]
    global metric_name
    nodeName = ['sv122','invader-26','i70','sv192','sv121']
    job = ['summary','haproxy','summary','system','summary']
    start_time= parse_datetime("10m")
    end_time = parse_datetime("now")
    chunk_size = timedelta(minutes=1)
    print("Sono nella future_violation\n")
    
    for i in range(5):
        
        label_config={'nodeName': nodeName[i], 'job': job[i]}    
        metric_data,diff_meta = configureParams(metric_name[i],label_config,start_time,end_time,chunk_size)

        
        metric_df=MetricRangeDataFrame(metric_data)
    
    
        data = metric_df.resample(rule='10s').mean(numeric_only='True')

        tsmodel = ExponentialSmoothing(data.dropna(),trend='add',seasonal='add',seasonal_periods=5).fit()
        prediction = tsmodel.forecast(10)
        
        print(prediction)
        
        for k in prediction:
            #print(k)
            v.append(k)

    
        json1[metric_name[i]]= {"values" : v}
        v=[]        

    print("\n-----------")
    print("Valori della prediction\n")
    print(json1)

    
    #Mando una post ad etl_data_pipeline contenente i valori della prediction

    res=requests.post('http://etl_data_pipeline:5000/ETL',json=json1)
    print(res.json)

    # continuo il flusso di elaborazione verificando anche in questo caso se ci saranno possibili violazioni

    for key in json1.keys():
        num_violation=0
        
        for k in json1[key].get('values'):
        #print(k)
            if not (float(fileJsonSLA[key].get('min')) < k < float(fileJsonSLA[key].get('max'))):
                num_violation = num_violation +1
            
        prediction_json[key]={"num_violation": num_violation}
        

    return prediction_json

def get_names(json_file):
    result=[]

    for name in json_file:
        #print(name)
        result.append(name)

    return result


@app.get('/')
def home():
    return render_template('homeSLA.html')

@app.route('/SLA',methods=['POST'])
def return_json():

    #POST recevuta dall'API tester (API TALEND tester)
    global file_jsonSla 
    global check_violation_json
    global prediction_violation_json
    global metric_name

    file_jsonSla=request.json

    metric_name= get_names(file_jsonSla)
    print(metric_name)
    print("Ho ricevuto il json dalla post\n")
    print("Calcolo di check violation e prediction violation\n")

    check_violation_json = check_violation(file_jsonSla)
    prediction_violation_json = prediction_violation(file_jsonSla)

    return "Risposta ricevuta!"

    
@app.get('/check_json')
def return_check_violation_json():
    if (len(check_violation_json)==0):
        return render_template('vuoto.html')
    
    return check_violation_json

@app.get('/prediction_json')
def return_prediction_violation_json():
    if (len(prediction_violation_json)==0):
        return render_template('vuoto.html')
    return prediction_violation_json

def configureParams(name, label, start_time ,end_time,chunk_size):
    start = time.time()

    metric_data = prom.get_metric_range_data(
      metric_name=name,
      label_config=label,
      start_time=start_time,
      end_time=end_time,
      chunk_size=chunk_size,
  )
    
    end= time.time()
    return metric_data, (end - start)

def create_values(metric_name,metric_df,x):
    global json_check
    v=[]
    
    for k in metric_df['value']:
        #print(k)
        v.append(k)

    key = metric_name +"-"+ x
    json_check[key]= {"values" : v}
    

if __name__ == "__main__":

    check_violation_json={}
    prediction_violation_json={}
    
    #res=requests.post('http://etl_data_pipeline:5000/test',json={"prova":"prova"})
    #print(res.json)
   
    app.run(port=5003,host="0.0.0.0",debug=False)