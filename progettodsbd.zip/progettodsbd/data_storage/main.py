from confluent_kafka import Consumer
import json
import mysql.connector


if __name__ == "__main__":
    
    #Data_storage

    
    try:
        c=Consumer({
                'bootstrap.servers':'kafka:29092',
                'group.id':'mygroup',
                'auto.offset.reset':'earliest'
        })
        c.subscribe(['prometheusdata'])
        
            
    except Exception:
        print(Exception)
        print("Errore durante connessione a kafka")
    
    
    
    mydb = mysql.connector.connect(
        host="db",
        user="user",
        password="pswd",
        database="DataStorage"
        )
    if mydb.is_connected():
        print("Connesso al db")
            
            
    
    # connessioni avvenute correttamente

    mycursor=mydb.cursor()
    
    # query per verificare che il db esista

    sql_select_Query = "show tables;"
    mycursor.execute(sql_select_Query)
        # get all records
    records = mycursor.fetchall()
    print("Total number of rows in table: ", mycursor.rowcount)

    print("\nPrinting each row")
    for row in records:
        print(row)
    

    print("Aspetto un messaggio\n")

    while True:
         
        msg = c.poll(1.0)
        
        if msg is None:
            continue
        if msg.error():
            print("Consumer error: {}".format(msg.error()))
            continue
        
        if str(msg.key())== "b'test'":
            print("Messaggio ricevuto")
            exit
        
        elif str(msg.key()) == "b'file1'":
            #tabella metadata metric_name/autocorrelazione/staz/seas
            
            fileJson2 = json.loads(msg.value())
            print(fileJson2)

            sql = """INSERT INTO metadata(metric_name,autocorrelation,stationarity,seasonality) VALUES(%s,%s,%s,%s);"""

            for key in fileJson2:
                autocorrelation = str(fileJson2[key]["Autocorrelazione"])
                stationarity = str(fileJson2[key]["Stazionarietà"])
                seasonality = str(fileJson2[key]["Stagionalità"])
                val=(key,autocorrelation,stationarity,seasonality)
                print(val)
                mycursor.execute(sql,val)
                mydb.commit()
                print("Ho caricato nel db metadata")
        
        elif str(msg.key()) == "b'file2'":
            #tabella prediction nome/max/min/avg
            filejson= json.loads(msg.value())
            print(filejson)
            sql=""" INSERT INTO prediction(metric_name,max,min,avarage) VALUES (%s,%s,%s,%s);"""

            for key in filejson:
                max=filejson[key]["max"]
                min=filejson[key]["min"]
                avg=filejson[key]["avg"]
                val=(key,max,min,avg)
                print(val)
                mycursor.execute(sql,val)
                mydb.commit()
                print("Ho caricato nel db prediction")
                        
        elif str(msg.key()) == "b'file3'":
            #tabella metriche 1/3/12  nome+starttime/max/min/avg/std
            filejson= json.loads(msg.value())
            print(filejson)
            sql=""" INSERT INTO metrics(metric_name,start_time,max,min,avarage,std) VALUES (%s,%s,%s,%s,%s,%s);"""

            for key in filejson:
                metric_name=str(filejson[key]["Metric_name"])
                start_time=str(filejson[key]["StartTime"])
                max=filejson[key]["max"]
                min=filejson[key]["min"]
                avg=filejson[key]["avg"]
                std=filejson[key]["std"]

                val=(metric_name,start_time,max,min,avg,std)
                print(val)
                mycursor.execute(sql,val)
                mydb.commit()
                print("Ho caricato nel db metrics")
        
        

     
    
