CREATE DATABASE IF NOT EXISTS DataStorage;
USE DataStorage;

CREATE TABLE if NOT EXISTS metadata (
    ID int AUTO_INCREMENT,metric_name varchar(255),
    autocorrelation varchar(255),
    stationarity varchar(255),
    seasonality MEDIUMTEXT,
    PRIMARY KEY (ID));
    
CREATE TABLE if NOT EXISTS prediction (
    ID int AUTO_INCREMENT,
    metric_name varchar(255),
    max double, 
    min double,
    avarage double, 
    PRIMARY KEY (ID));

CREATE TABLE if NOT EXISTS metrics (
    ID int AUTO_INCREMENT,
    metric_name varchar(255),
    start_time varchar(255), 
    max double,
    min double,
    avarage double,
    std double, 
    PRIMARY KEY (ID));