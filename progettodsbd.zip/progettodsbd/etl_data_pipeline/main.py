import prometheus_api_client.exceptions
from flask import Flask , request
from prometheus_api_client import PrometheusConnect , MetricsList , MetricRangeDataFrame
from datetime import timedelta
from prometheus_api_client.utils import parse_datetime
import json
from confluent_kafka import Producer
import sys
import pandas as pd
import time
from statsmodels.tsa.holtwinters import ExponentialSmoothing
from statsmodels.tsa.seasonal import seasonal_decompose
import statsmodels.api as sm
from statsmodels.tsa.stattools import adfuller

app = Flask(__name__)

try:
    prom = PrometheusConnect(url="http://15.160.61.227:29090",disable_ssl=True)
except prometheus_api_client.exceptions.PrometheusApiClientException as e:
    sys.exit("ERRORE CONNESSIONE AL PROMETHEUS")



def configureParams(name, label, start_time ,end_time,chunk_size):
    start = time.time() # usato per monitorare tempo di esecuzione istruzione dopo

    #print(start_time)
    metric_data = prom.get_metric_range_data(
      metric_name=name,
      label_config=label,
      start_time=start_time,
      end_time=end_time,
      chunk_size=chunk_size,
    )
    end= time.time()
    return metric_data, (end - start)


def calculate_values(metric_name, metric_df,start_time):
    
    
    data = {"Metric_name": metric_name,
                "StartTime": start_time,
                "max":metric_df['value'].max(),
                "min":metric_df['value'].min(),
                "avg":metric_df['value'].mean(),
                "std":metric_df['value'].std()}
    return data
    
    

def seasonal(values):
    result_seasonal = seasonal_decompose(values, model='additive', period=5)
    
    serializable_result = {str(k): round(v, 3) for k, v in result_seasonal.seasonal.to_dict().items()}

    return serializable_result

def stationarity(values):

    stationarityTest = adfuller(values, autolag='AIC')

    if stationarityTest[1] <= 0.05:
        result = 'stationary series'
    else:
        result = 'no stationary series'

    return result

def autocorrelation(values):
    lags = len(values)
    result = 'non autocorrelated series'
    result_autocorr = sm.tsa.acf(values, nlags=lags-1).tolist()
    for lag in result_autocorr:
        if lag <= 0.05:
            result = 'autocorrelated series'


    return result

def max(list):
    
    max=list[0]
    
    for x in list:
        if(max < x):
            max=x
    return max

def min(list):
    min=list[0]
    for x in list:
        if(min > x):
            min=x
    return min

def avg(list):
    avg=0
    for x in list:
        avg= avg+x

    return avg/len(list)


def predict(prediction):
    dictPred={}
    for name in prediction:
        dictPred[name]={"max":max(prediction[name]['values']),"min":min(prediction[name]['values']),"avg":avg(prediction[name]['values'])}
    
    return dictPred

def metaCalc(metric_df):
    dictValues = {"Autocorrelazione": autocorrelation(metric_df['value']),
                  "Stazionarietà": stationarity(metric_df['value']),
                  "Stagionalità": seasonal(metric_df['value']),
                  }
    return dictValues


def sendTokafka(fileJson,key_file):

    #Etl_data_pipeline 

    broker= "kafka:29092"
    topic="prometheusdata"
    conf={'bootstrap.servers':broker}
    p=Producer(**conf)
    
    def delivery_callback(err, msg):
        if err:
            sys.stderr.write('%% Message failed delivery: %s\n' % err)
        else:
            sys.stderr.write('%% Message delivered to %s [%d] @ %d\n' %
                             (msg.topic(), msg.partition(), msg.offset()))

    try:
        value= json.dumps(fileJson)
        
        p.produce(topic, key = key_file, value=value, callback=delivery_callback)
    except BufferError:
        sys.stderr.write(' Error during sendToKafka \n' )

    p.poll(0)
    p.flush()

@app.route('/test',methods=['POST'])
def func():
    print("ho ricevuto : \n")
    print(request.json)

    return "ok!"


@app.route('/ETL',methods=['POST'])
def return_json_prediction():
    
    print("Ho ricevuto : \n")
    print(request.json)
    print("Sto elaborando : \n")
    print(predict(request.json))
    
    sendTokafka(predict(request.json),'file2')

    return "Risposta ricevuta!"

if __name__ == "__main__":
    

    print("Main ETL starting...")
    time.sleep(5)

    # inizializzazione variabili utilizzate

    result={}
    result2={}
    time_execution_start=0
    time_end_execution=0

    # metriche prese in esame
    metric_name = ['availableMem','CpuUsage','cpuTemp','totProcesses','networkThroughput']
    nodeName = ['sv122','invader-26','i70','sv192','sv121']
    job = ['summary','haproxy','summary','system','summary']
    start_time = ["10m","15m","20m"] #1,3,12h

    start_time_metadata = parse_datetime("10m") #12h 
    end_time = parse_datetime("now")
    chunk_size = timedelta(minutes=1)
    
    print("Parametri settati\n")

    # Calcolo di max,min,avg e dev_std per le metriche con start_time di 1/3/12 h
    
    print("Inizio calcolo di metrics\n")
    
    for i in range(5):
        for x in start_time:
            label_config={'nodeName': nodeName[i], 'job': job[i]}
            
            metric_data,diff_meta = configureParams(metric_name[i],label_config,parse_datetime(x),end_time,chunk_size)

            print("Tempo di scraping di "+ metric_name[i]+ " : "+ str(diff_meta)+" s")

            metric_object_list = MetricsList(metric_data)
            metric_df= MetricRangeDataFrame(metric_data)

            key_dict= metric_name[i]+'-'+x

            time_execution_start= time.time()

            result2[key_dict]= calculate_values(metric_name[i],metric_df,x)

            time_end_execution=time.time()
            print("Tempo di esecuzione "+ metric_name[i]+ " : "+ str(time_end_execution-time_execution_start) +" s")
    
    print("Calcolo di metrics completato\n")
    print("Invio al db in corso...\n")
    
    #print(result2)
    sendTokafka(result2,'file3')
    print("Invio completato \n")


    print("Inizio calcolo di autocorrelazione/stazionarità/stagionalità\n")
    
    # Calcolo di autocorrelazione/stazionarietà/stagionalità
    for i in range(5):
        label_config={'nodeName': nodeName[i], 'job': job[i]}

        metric_data,diff_meta = configureParams(metric_name[i],label_config,start_time_metadata,end_time,chunk_size)

        print("Tempo di scraping di "+ metric_name[i]+ " : "+ str(diff_meta)+" s")

        metric_object_list = MetricsList(metric_data)
        metric_df= MetricRangeDataFrame(metric_data)
        
        time_execution_start= time.time()  #usato per monitorare il tempo di esecuzione dell'operazione che segue

        result[metric_name[i]] = metaCalc(metric_df)

        time_end_execution=time.time()
        print("Tempo di esecuzione "+ metric_name[i]+ " : "+ str(time_end_execution-time_execution_start) +" s")


    print("Calcolo dei metadati completato\n")
    print("Invio al db in corso...\n")

    print(result)
    sendTokafka(result,'file1')

    print("Invio completato \n")
    
    
    app.run(port=5000,host="0.0.0.0",debug=False)