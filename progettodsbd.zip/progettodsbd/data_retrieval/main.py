from flask import Flask , render_template
import mysql.connector

app = Flask(__name__)
while True:
    mydb = mysql.connector.connect(
            host="db",
            user="user",
            password="pswd",
            database="DataStorage"
            )

    if mydb.is_connected():
        print("Connesso al db")
        break

mycursor=mydb.cursor()

@app.get('/')
def home_page():
    return render_template('homeDTR.html')

@app.get('/metrics')
def get_metrics():
    sql="""SELECT * from metrics;"""
    mycursor.execute(sql)
    json_metrics={}
    list_metrics=[]
    y=0

    for x in mycursor:
        list_metrics.append(x)
        key= ""+list_metrics[y][1] +""+""+ list_metrics[y][2]
        start_time= list_metrics[y][2]
        max_metrics=list_metrics[y][3]
        min_metrics=list_metrics[y][4]
        avg_metrics=list_metrics[y][5]
        std_metrics=list_metrics[y][6]
        json_metrics[key] = { "start_time": start_time,
                                            "max": max_metrics,
                                            "min": min_metrics,
                                            "avg":avg_metrics,
                                            "std":std_metrics
                                            }
        y=y+1
    
    if (len(json_metrics)==0):
        return render_template('vuoto.html')
    return json_metrics

@app.get('/predict')
def get_predict():
    sql="""SELECT * from prediction;"""
    mycursor.execute(sql)
    json_metrics={}
    list_metrics=[]
    y=0

    for x in mycursor:
        list_metrics.append(x)
        max_metrics=list_metrics[y][2]
        min_metrics=list_metrics[y][3]
        avg_metrics=list_metrics[y][4]
        json_metrics[list_metrics[y][1]] = {
                                            "max": max_metrics,
                                            "min": min_metrics,
                                            "avg":avg_metrics
                                            }
        y=y+1
    
    if (len(json_metrics)==0):
        return render_template('vuoto.html')
    return json_metrics

@app.get('/metadata')
def get_meta():
    sql="""SELECT * from metadata;"""
    mycursor.execute(sql)
    json_metrics={}
    list_metrics=[]
    y=0

    for x in mycursor:
        list_metrics.append(x)
        autocorr=list_metrics[y][2]
        stazz=list_metrics[y][3]
        season=list_metrics[y][4]
        json_metrics[list_metrics[y][1]] = {
                                            "Autocorrelazione":autocorr,
                                            "Stazionarietà": stazz,
                                            "Stagionalità":season
                                            }
        
        y=y+1
    if (len(json_metrics)==0):
        return render_template('vuoto.html')
    return json_metrics


if __name__ == "__main__":
    print("\nMain data_retrieval")


    app.run(port = "5002",host="0.0.0.0",debug=False)